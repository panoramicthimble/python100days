#1. Create a greeting for your program.
print("Welcome to the band name generator!\nWill you be the next super group!?\n")
#2. Ask the user for the city that they grew up in.
city = input("\nWhat city did you grow up in? ")
#3. Ask the user for the name of a pet.
pet = input("\nWhat was the name of your favourite pet?\n(or first, if you can't decide who gets that denomination): ")
#4. Combine the name of their city and pet and show them their band name.
print("\nHow about calling your band " + city + " " + pet + "?\n")
#5. Make sure the input cursor shows on a new line, see the example at:
#   https://replit.com/@appbrewery/band-name-generator-end